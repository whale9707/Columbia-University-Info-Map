import React from 'react';
import './homePage.css';
import { useNavigate } from "react-router-dom";
import { Col, Container, Row } from 'react-bootstrap';


export default function Home() {
  const history = useNavigate()

  function handleBuilding() {
    history('/building');
  }

  function handleFacility() {
    history('/facility');
  }

  return (
    <Container>
      <Row>
       <Col className="home-container">
       <h2 className="home-title">Columbia University Info Map</h2>
      <p className="home-intro">
      An interactive campus map of Columbia University in the City of New York that provides effective builidng findings with facility filtering options.
      </p>
       </Col>
       </Row>
       <Row>
       <button className='button' onClick={handleFacility}>
        Filter By Facilities
      </button>
      <button className='button' onClick={handleBuilding}>
        Search By Building Name
      </button>
      </Row>
    </Container>
  )
}
