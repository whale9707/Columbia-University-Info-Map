import React, { useEffect } from "react";
import { Button, FormGroup, FormControlLabel, Checkbox } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import Box from "@mui/material/Box";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import "./facility.css";
import data from "../BuildingPage/BuildingName";
import { useRecoilState } from "recoil";
import { searchMks } from "../map/data";
import { useNavigate } from "react-router-dom";


export default function FacilityPage() {
  const history = useNavigate()
  function backHome() {
    history('/');
  }

  const [mks, setMks] = useRecoilState(searchMks);

  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  }));

  const [option, setOption] = React.useState({
    "Library": false,
    "Hotwater": false,
    "Microwave": false,
    "Café": false,
    "Vending Machine": false,
    "Gender Neutral Restroom": false,
  });

  const [res, setRes] = React.useState([]);

  function handleChange(e) {
    setOption({ ...option, [e.target.name]: e.target.checked });
  }
  useEffect(() => {
    const newOption = Object.keys(option).filter((key) => option[key]);
    const newData = data.filter((item) => {
      return newOption.every((option) => item.facility.includes(option));
    });

    setRes(newData);
    setMks(newData);
   
  }, [option]);

  const searchMarks = () => {
    history('/');

  };
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
        <Grid xs={12}>
          <Button
            variant="contained"
            className="back"
            onClick={() => backHome()}
          >
            Back
          </Button>
        </Grid>

        <div className="check-group">
          <FormGroup>
            <FormControlLabel
              onChange={(e) => handleChange(e)}
              control={<Checkbox checked={option.Library} name="Library" />}
              label="Library"
            />
            <FormControlLabel
              onChange={(e) => handleChange(e)}
              control={<Checkbox name="Hotwater" checked={option.Hotwater} />}
              label="Hotwater"
            />
            <FormControlLabel
              onChange={(e) => handleChange(e)}
              control={<Checkbox name="Microwave" checked={option.Microwave} />}
              label="Microwave"
            />
            <FormControlLabel
              onChange={(e) => handleChange(e)}
              control={<Checkbox name="Café" checked={option.Café} />}
              label="Café"
            />
            <FormControlLabel
              onChange={(e) => handleChange(e)}
              control={<Checkbox name="Gender Neutral Restroom" checked={option.Gender} />}
              label="Gender Neutral Restroom"
            />
            <FormControlLabel
              onChange={(e) => handleChange(e)}
              control={<Checkbox checked={option.Vending} name="Vending Machine" />}
              label="Vending Machine"
            />
          </FormGroup>
        </div>
        <Grid xs={8}>
          <Item> {res.length}results</Item>
        </Grid>
        <Grid xs={4}>
          <Button variant="contained" color="success" onClick={searchMarks}>
            Search
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
}
