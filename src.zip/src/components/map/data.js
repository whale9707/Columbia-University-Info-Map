/* store data of buildings in Columbia campus*/
import { atom } from "recoil";

export const postionData = atom({
  key: "postionData",
  default:  {
    value: "BUT",
    lat: 40.80663056839071,
    lng: -73.96318047358015,
    label: "(BUT) Butler library",
    facility: ["Hotwater", "Microwave", "Café", "Gender Neutral Restroom"],
    info: {
      'Hotwater': "3rd Floor, Room 301",
      'Microwave': "4th Floor, Room 403",
      // 'Café': "Open Hours: 8:00AM - 8:00PM; Floor: 6th Floor",
      'Gender Neutral Restroom': "2nd Floor",
    },
  },
  
});
export const searchMks = atom({
  key: "searchMks",
  default: [
    {
      value: "BUT",
      lat: 40.80663056839071,
      lng: -73.96318047358015,
      label: "(BUT) Butler library",
      facility: ["Hotwater", "Microwave", "Café", "Gender Neutral Restroom"],
      info: {
        'Hotwater': "3rd Floor, Room 301",
        'Microwave': "4th Floor, Room 403",
        // 'Café': "Open Hours: 8:00AM - 8:00PM; Floor: 6th Floor",
        'Gender Neutral Restroom': "2nd Floor",
      },
    },
    {
      value: "HAM",
      lat: 40.80696927514045,
      lng: -73.96172054659247,
      label: "(HAM) Hamilton Hall",
      facility: ["Hotwater", "Microwave", "Lactation Room"],
      info: {
        'Hotwater': "2nd Floor, Room 204",
        'Microwave': "5th Floor, Room 505",
        "Lactation Room": "3rd Floor, Room 310",
      },
    },
    {
      value: "HAV",
      lat: 40.80949109249354,
      lng: -73.96209702755544,
      label: "(HAV) Havemeyer Hall",
      facility: ["Café", "Hotwater", "Vending Machine"],
      info: {
        "Café": "Open Hours: 8:00AM - 8:00PM; Floor: 6th Floor",
        "Hotwater": "3rd Floor; Room 310",
        "Vending Machine": "3rd Floor, Room 300",
      },
    },
    {
      value: "KNT",
      lat: 40.807337091106206,
      lng: -73.96111602385994,
      label: "(KNT) Kent Hall",
      facility: ["Gender Neutral Restroom", "Library", "Hotwater"],
      info: {
        "Gender Neutral Restroom": "2nd Floor",
        "Library": "Open Hours: 10:00AM-10:00PM; Floor: 1st Floor",
        "Hotwater": "3rd Floor; Room 310",
      },
    },
    {
      value: "MUD",
      lat: 40.80958043327859,
      lng: -73.95988187358012,
      label: "(MUD) Mudd Building",
      facility: ["Hotwater", "Microwave", "Gender Neutral Restroom"],
      info: {
        "Hotwater": "2nd Floor, Room 206",
        "Microwave": "4th Floor, Room 404",
        "Gender Neutral Restroom": "3rd Floor",
      },
    },
    {
      value: "PHI",
      lat: 40.80763549435218,
      lng: -73.96081868522616,
      label: "(PHI) Philosophy Hall",
      facility: ["Library", "Microwave", "Hotwater"],
      info: {
        "Library": "Open Hours: 24 Hours; Floor: 9th Floor",
        "Microwave": "4th Floor, Room 403",
        "Hotwater": "5th Floor, Room 503",
      },
    },
    {
      value: "PUP",
      lat: 40.81024636885703,
      lng: -73.96151818465844,
      label: "(PUP) Pupin Laboratories",
      facility: ["Library", "Gender Neutral Restroom","Vending Machine"],
      info: {
        "Library": "Open Hours: 9:00AM - 10:00PM; Floor: 3rd Floor",
        "Gender Neutral Restroom": "2nd Floor",
        "Vending Machine": "2nd Floor",
      },
    },
  ],
});
