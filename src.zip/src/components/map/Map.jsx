import React, { useState, useRef } from "react";
import GoogleMapReact from "google-map-react";
import Button from "@mui/material/Button";
import { Icon } from "@iconify/react";
import locationIcon from "@iconify/icons-mdi/map-marker";
import { postionData, searchMks } from "./data";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import "./map.css";
import { useRecoilValue, useRecoilState } from "recoil";

const LocationPin = ({ text, onClick }) => (
  <div className="pin" onClick={onClick}>
    <Icon icon={locationIcon} className="pin-icon" />
    <p className="pin-text">{text}</p>
  </div>
);

const mapStyles = {
  width: '100%',
  bottom: '-0.05',
  height: '100%',
  position: "absolute",
  // marginbottom :'-1',
  

  "z-index": "-1"
};

const Map = ({ location, zoomLevel }) => {
  const mks = useRecoilValue(searchMks);
  const [isTabVisible, setIsTabVisible] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [pos, setPos] = useRecoilState(postionData);
  const areaRef = useRef(null);

  const handleLocationPinClick = (mk) => {
    if (mk) {
      setPos(mk);
    }
    setIsTabVisible(true);
    setIsVisible(true);
  };
  let pin = null;
  if (isTabVisible) {
    console.log(pos);
    const entries = Object.entries(pos.info);
    pin = (
      <>
        ( 
        <div
          className="detail-info"
          ref={areaRef}
          onClick={() => setIsVisible(!isVisible)}
        >
          {entries.map((entry) => (
            <div>
              <Accordion>
                <AccordionSummary
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <Typography>{entry[0]}</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    {entry[1]}
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </div>
          ))}
          <Button variant="contained" onClick={() => setIsTabVisible(false)}>
            closed
          </Button>
        </div>
        )
      </>
    );
  } else {
    pin = (
      <LocationPin
        text={pos.name}
        lat={pos.lat}
        lng={pos.lng}
        onClick={handleLocationPinClick}
      />
    );
  }
  return (
        <GoogleMapReact
          bootstrapURLKeys={{ key: "AIzaSyBW7LLnGlsaZCebaVdcLJ_9N45tOrg01x8" }}
          defaultCenter={pos}
          defaultZoom={zoomLevel}
          center={pos}
          style={mapStyles}
        >
          {pin}
          {mks.map((mk) => (
            <LocationPin
              text={mk.label}
              lat={mk.lat}
              lng={mk.lng}
              onClick={() => handleLocationPinClick(mk)}
            />
          ))}
        </GoogleMapReact>
  );
};

export default Map;
