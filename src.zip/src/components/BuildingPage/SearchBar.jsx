import "./buildingPage.css";
import Select from "react-select";
import React from "react";
import data from "./BuildingName";
import { postionData, searchMks } from "../map/data";
import { useRecoilState } from "recoil";
import Button from "@mui/material/Button";
export default function MyFunctionalComponent() {

  console.log(searchMks);
  const [count, setCount] = useRecoilState(postionData);
  const [count1, setCount1] = useRecoilState(searchMks);
  const handleChange = (selectedOption) => {
    setCount(selectedOption);
    setCount1([selectedOption]);
  };

   const handleBack = () => {
    window.location.href = '/'
  }
  return (
    <>
      <Select
        className="search-container"
        name="form-field-name"
        onChange={handleChange}
        options={data}
        value={count}
      ></Select>
      <Button variant="contained" onClick={handleBack}>Back</Button>
    </>
  );
}
