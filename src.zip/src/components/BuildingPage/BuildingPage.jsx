import React, { Component } from "react";
import SearchBar from "./SearchBar";
import "./buildingPage.css";
import { Col, Container, Row } from "react-bootstrap";

export default class Building extends Component {

  render() {
   
    return (
      <Container>
        <Row>
          <Col className="home-container">
            <SearchBar className="search-container" />
          </Col>
        </Row>
      </Container>
    );
  }
}
