import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomeSection from "./components/HomePage/HomePage";
import MapSection from "./components/map/Map";
import BuildingSection from "./components/BuildingPage/BuildingPage";
import FacilitySection from "./components/FacilityPage/FacilityPage";
import "./App.css";
import { RecoilRoot } from "recoil";
import { postionData } from "./components/map/data";

export default function App() {
  return (
    <RecoilRoot>
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <>
                <HomeSection />
                <MapSection location={postionData} zoomLevel={17} />
              </>
            }
          />
          <Route
            path="/building"
            element={
              <>
                <BuildingSection />
                <MapSection location={postionData} zoomLevel={17} />
              </>
            }
          />
          <Route path="/facility" element={<FacilitySection />} />
        </Routes>
      </BrowserRouter>
    </RecoilRoot>
  );
}
